OOOO AI TRADER — Quant Terminal V2

FILES
- index.html: responsive trading terminal, signals, paper trading, charts, agent visualizer
- manifest.webmanifest: PWA metadata
- sw.js: simple app-shell cache for offline loading after first successful visit
- icon.svg: app icon

PUBLISH ON GITHUB PAGES
1. Open your GitHub repository: Takrim0/OOOO-AI-TRADER.
2. Replace the existing root index.html with this package's index.html.
3. Add manifest.webmanifest, sw.js, and icon.svg at the repository root.
4. Commit changes to main.
5. In Settings > Pages, select Deploy from a branch, branch main, folder /(root), then Save.
6. Wait for the Pages deployment to finish and open https://takrim0.github.io/OOOO-AI-TRADER/ .
7. Test the site on Android before wrapping it into an APK.

CREATE APK
Use your WebToApp app to create an app from the published URL. Enter:
https://takrim0.github.io/OOOO-AI-TRADER/
App name: OOOO AI TRADER
Choose the icon if the builder offers it, then Preview and Save/Build APK. The exact export button names depend on the WebToApp version.

IMPORTANT
This is a front-end demo. It generates simulated prices and rule-based demo signals locally. It does not connect to live exchanges, provide verified AI predictions, or place real-money trades. Paper account state may be saved in this browser/device only.
